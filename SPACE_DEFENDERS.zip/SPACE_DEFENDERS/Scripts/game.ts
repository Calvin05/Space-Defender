//IIFE -- Immediately Invoked Function Expression
// mean? is an anonymous self-executing function
let Game = (function(){
    let canvas:HTMLCanvasElement = document.getElementsByTagName('canvas')[0];
    let stage:createjs.Stage;
    let speedX = 2;
    let player01: objects.Player;
    let background: createjs.Bitmap;
    let enemy: createjs.Bitmap;

    /**
     * This method initializes the CreateJS Library
     * It sets the framerate to 60FPS and sets up the main Game Loop (update)
     */
    function Start():void{
        console.log(`%c Game Started`, "color: blue; font-size:20px;");
        
        stage = new createjs.Stage(canvas);
        createjs.Ticker.framerate = 60; // declare the framerate as 60FPS
        createjs.Ticker.on('tick', Update);
        stage.enableMouseOver(20);
        Main();

    }

    /**
     * This function is triggered every frame (16ms)
     * The stage is then erased and redrawn
     */

    function MovingEnamy():void{
        if(enemy.x >= 600 - enemy.getBounds().width*0.5){
            speedX = -2;
        }
        if(enemy.x <= enemy.getBounds().width *0.5){
            speedX = 2;
        }
    }

    function Update():void{
        enemy.x += speedX;
        MovingEnamy();
        stage.update();
    }

    /**
     * This is the main function of the Game
     */
    function Main():void{
        console.log(`%c Main Started...`, "color: green; font-size:16px;");
        //load backGround image
        background = new createjs.Bitmap('/Assets/images/BackGround-01.png');
        stage.addChild(background);

        enemy = new objects.Enemy('./Assets/images/enemy.png',300, 200, true);
        stage.addChild(enemy);

        //player
        player01 = new objects.Player('./Assets/images/Player.png', 300, 600, true);
        stage.addChild(player01);

    }
    window.addEventListener('load', Start);

})();