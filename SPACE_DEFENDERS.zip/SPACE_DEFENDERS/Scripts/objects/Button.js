"use strict";
var objects;
(function (objects) {
    class Button extends createjs.Bitmap {
        //constructor
        constructor(imagePath = './Assets/images/Player.png', x = 0, y = 0, isCentered = false) {
            super(imagePath);
            this.image.addEventListener('load', () => {
                console.log("image finished loading");
                if (isCentered) {
                    this.regX = this.getBounds().width * 0.5;
                    this.regY = this.getBounds().height * 0.5;
                }
                this.x = x;
                this.y = y;
            });
            this.on("mouseover", this.MouseOver);
            this.on("mouseover", this.MouseOut);
        }
        MouseOver() {
            this.alpha = 0.7;
        }
        MouseOut() {
            this.alpha = 1.0;
        }
    }
    objects.Button = Button;
})(objects || (objects = {}));
//# sourceMappingURL=Button.js.map