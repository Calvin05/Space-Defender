"use strict";
var objects;
(function (objects) {
    class Enemy extends createjs.Bitmap {
        constructor(imagePath = './Assets/images/enemy.png', x = 0, y = 0, isCentered = false, bullets = 1000) {
            super(imagePath);
            this.image.addEventListener('load', () => {
                console.log("image finished loading");
                if (isCentered) {
                    this.regX = this.getBounds().width * 0.5;
                    this.regY = this.getBounds().height * 0.5;
                }
                this.x = x;
                this.y = y;
            });
        }
    }
    objects.Enemy = Enemy;
})(objects || (objects = {}));
//# sourceMappingURL=Enemy.js.map