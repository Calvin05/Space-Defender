"use strict";
var objects;
(function (objects) {
    class Player extends createjs.Bitmap {
        constructor(imagePath = './Assets/images/enemy.png', x = 0, y = 0, isCentered = false) {
            super(imagePath);
            this.image.addEventListener('load', () => {
                console.log("image finished loading");
                if (isCentered) {
                    this.regX = this.getBounds().width * 0.5;
                    this.regY = this.getBounds().height * 0.5;
                }
                this.x = x;
                this.y = y;
            });
        }
    }
    objects.Player = Player;
})(objects || (objects = {}));
//# sourceMappingURL=Player.js.map