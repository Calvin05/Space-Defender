module objects{
    export class Player extends createjs.Bitmap{

        constructor(imagePath:string = './Assets/images/enemy.png', x:number = 0, y:number = 0,isCentered: boolean= false){
            super(imagePath);
            this.image.addEventListener('load', () => {
                console.log("image finished loading")

                if(isCentered){
                    this.regX = this.getBounds().width * 0.5;
                    this.regY = this.getBounds().height * 0.5;
                }
                this.x = x
                this.y = y

            });
        }

    }
}